package com.udb.ucacfcconnect;

import com.udb.ucacfcconnect.model.Espacio;
import com.udb.ucacfcconnect.model.SolicitudAlquiler;
import com.udb.ucacfcconnect.model.enums.EstadoSolicitud;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.LocalTime;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Ejemplo de pruebas unitarias sobre la regla de negocio "seSolapaCon" de
 * SolicitudAlquiler, tal como pide el enunciado (Requisitos Técnicos ->
 * Pruebas Unitarias):
 *   - Caso de éxito: reserva correcta cuando el aula y el horario están libres.
 *   - Caso de fallo por solapamiento: existe una reserva a la misma hora.
 *
 * Nota: esta clase prueba la lógica del dominio de forma aislada (sin Spring
 * Context ni base de datos). El compañero que implemente el Service de
 * Alquiler de Espacios puede extenderla con Mockito para simular el
 * repositorio y lanzar EspacioOcupadoException cuando corresponda.
 */
class SolicitudAlquilerTest {

    private Espacio crearAuditorio() {
        Espacio espacio = new Espacio();
        espacio.setId(1L);
        espacio.setNombre("Auditorio Principal");
        return espacio;
    }

    private SolicitudAlquiler crearSolicitud(Espacio espacio, LocalDate fecha, LocalTime inicio, LocalTime fin) {
        SolicitudAlquiler s = new SolicitudAlquiler();
        s.setEspacio(espacio);
        s.setFecha(fecha);
        s.setHoraInicio(inicio);
        s.setHoraFin(fin);
        s.setEstado(EstadoSolicitud.PENDIENTE);
        return s;
    }

    @Test
    void casoExito_reservaSinConflicto_noSeSolapan() {
        Espacio espacio = crearAuditorio();
        SolicitudAlquiler existente = crearSolicitud(espacio, LocalDate.of(2026, 10, 4),
                LocalTime.of(9, 0), LocalTime.of(12, 0));
        SolicitudAlquiler nueva = crearSolicitud(espacio, LocalDate.of(2026, 10, 4),
                LocalTime.of(13, 0), LocalTime.of(15, 0));

        assertFalse(existente.seSolapaCon(nueva), "No deberían solaparse: son horarios distintos el mismo día");
    }

    @Test
    void casoFallo_solapamientoMismoHorario_seSolapan() {
        Espacio espacio = crearAuditorio();
        SolicitudAlquiler existente = crearSolicitud(espacio, LocalDate.of(2026, 10, 4),
                LocalTime.of(9, 0), LocalTime.of(12, 0));
        SolicitudAlquiler nueva = crearSolicitud(espacio, LocalDate.of(2026, 10, 4),
                LocalTime.of(11, 0), LocalTime.of(13, 0));

        assertTrue(existente.seSolapaCon(nueva), "Deben solaparse: 11-13 se cruza con 9-12");
    }

    @Test
    void casoFallo_espacioDistinto_noSeSolapanAunqueMismoHorario() {
        Espacio auditorio = crearAuditorio();
        Espacio laboratorio = new Espacio();
        laboratorio.setId(2L);
        laboratorio.setNombre("Laboratorio 1");

        SolicitudAlquiler enAuditorio = crearSolicitud(auditorio, LocalDate.of(2026, 10, 4),
                LocalTime.of(9, 0), LocalTime.of(12, 0));
        SolicitudAlquiler enLaboratorio = crearSolicitud(laboratorio, LocalDate.of(2026, 10, 4),
                LocalTime.of(9, 0), LocalTime.of(12, 0));

        assertFalse(enAuditorio.seSolapaCon(enLaboratorio), "Espacios distintos nunca se solapan");
    }
}
