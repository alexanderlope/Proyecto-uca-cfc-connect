package com.udb.ucacfcconnect.model;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@DiscriminatorValue("CURSO")
@Getter
@Setter
@NoArgsConstructor
public class Curso extends OfertaAcademica {
    // No agrega columnas propias: usa exactamente las de oferta_academica.
}
