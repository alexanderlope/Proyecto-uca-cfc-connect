package com.udb.ucacfcconnect.model.enums;

public enum TipoOfertaAcademica {
    CURSO,
    DIPLOMADO
}
