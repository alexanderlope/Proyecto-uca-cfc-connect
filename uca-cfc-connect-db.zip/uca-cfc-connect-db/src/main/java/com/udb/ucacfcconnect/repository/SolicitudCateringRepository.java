package com.udb.ucacfcconnect.repository;

import com.udb.ucacfcconnect.model.SolicitudCatering;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface SolicitudCateringRepository extends JpaRepository<SolicitudCatering, Long> {

    Page<SolicitudCatering> findByClienteId(Long clienteId, Pageable pageable);

    List<SolicitudCatering> findByLugarAndFecha(String lugar, LocalDate fecha);
}
