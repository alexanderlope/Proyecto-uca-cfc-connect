package com.udb.ucacfcconnect.model.enums;

public enum EstadoPago {
    PENDIENTE,
    PARCIAL,
    PAGADO
}
