package com.udb.ucacfcconnect.repository;

import com.udb.ucacfcconnect.model.SolicitudAlquiler;
import com.udb.ucacfcconnect.model.enums.EstadoSolicitud;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

public interface SolicitudAlquilerRepository extends JpaRepository<SolicitudAlquiler, Long> {

    Page<SolicitudAlquiler> findByClienteId(Long clienteId, Pageable pageable);

    List<SolicitudAlquiler> findByEspacioIdAndFecha(Long espacioId, LocalDate fecha);

    /**
     * Devuelve las solicitudes activas (no canceladas ni rechazadas) del mismo
     * espacio y fecha que se solapan con el rango [horaInicio, horaFin).
     * El Service la usa para lanzar EspacioOcupadoException si la lista no está vacía.
     */
    @Query("SELECT s FROM SolicitudAlquiler s WHERE s.espacio.id = :espacioId " +
           "AND s.fecha = :fecha " +
           "AND s.estado NOT IN (com.udb.ucacfcconnect.model.enums.EstadoSolicitud.CANCELADA, " +
           "com.udb.ucacfcconnect.model.enums.EstadoSolicitud.RECHAZADA) " +
           "AND s.horaInicio < :horaFin AND s.horaFin > :horaInicio")
    List<SolicitudAlquiler> findSolapadas(@Param("espacioId") Long espacioId,
                                           @Param("fecha") LocalDate fecha,
                                           @Param("horaInicio") LocalTime horaInicio,
                                           @Param("horaFin") LocalTime horaFin);

    Page<SolicitudAlquiler> findByEstado(EstadoSolicitud estado, Pageable pageable);
}
