package com.udb.ucacfcconnect.model.enums;

public enum TipoActividad {
    CURSO,
    DIPLOMADO,
    EVENTO,
    ALQUILER,
    CATERING
}
