package com.udb.ucacfcconnect.repository;

import com.udb.ucacfcconnect.model.Cliente;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ClienteRepository extends JpaRepository<Cliente, Long> {

    Optional<Cliente> findByDuiNit(String duiNit);

    // Soporta el endpoint GET /api/clientes/buscar?nombre=
    Page<Cliente> findByNombreContainingIgnoreCaseOrEmpresaContainingIgnoreCaseOrDuiNitContainingIgnoreCase(
            String nombre, String empresa, String duiNit, Pageable pageable);
}
