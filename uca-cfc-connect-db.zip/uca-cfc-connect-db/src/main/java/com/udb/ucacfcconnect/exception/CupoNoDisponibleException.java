package com.udb.ucacfcconnect.exception;

/** Se lanza al intentar inscribir un participante en un curso/diplomado sin cupo disponible. */
public class CupoNoDisponibleException extends NegocioException {
    public CupoNoDisponibleException(String mensaje) {
        super(mensaje);
    }
}
