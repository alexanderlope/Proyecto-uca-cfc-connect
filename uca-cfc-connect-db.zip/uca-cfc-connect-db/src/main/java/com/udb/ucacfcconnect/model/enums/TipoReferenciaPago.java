package com.udb.ucacfcconnect.model.enums;

public enum TipoReferenciaPago {
    INSCRIPCION,
    COTIZACION,
    ALQUILER,
    CATERING
}
