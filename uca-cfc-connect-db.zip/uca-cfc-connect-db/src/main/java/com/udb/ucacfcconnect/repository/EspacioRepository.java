package com.udb.ucacfcconnect.repository;

import com.udb.ucacfcconnect.model.Espacio;
import com.udb.ucacfcconnect.model.enums.TipoEspacio;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EspacioRepository extends JpaRepository<Espacio, Long> {

    Page<Espacio> findByDisponibleTrue(Pageable pageable);

    Page<Espacio> findByTipoAndDisponibleTrue(TipoEspacio tipo, Pageable pageable);
}
