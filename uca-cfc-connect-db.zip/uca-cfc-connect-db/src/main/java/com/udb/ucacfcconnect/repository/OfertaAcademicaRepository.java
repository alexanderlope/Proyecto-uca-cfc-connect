package com.udb.ucacfcconnect.repository;

import com.udb.ucacfcconnect.model.OfertaAcademica;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface OfertaAcademicaRepository extends JpaRepository<OfertaAcademica, Long> {

    Page<OfertaAcademica> findByActivoTrue(Pageable pageable);

    Page<OfertaAcademica> findByCategoriaIdAndActivoTrue(Long categoriaId, Pageable pageable);

    Page<OfertaAcademica> findByModalidadIdAndActivoTrue(Long modalidadId, Pageable pageable);

    @Query("SELECT o FROM OfertaAcademica o WHERE " +
           "(:nombre IS NULL OR LOWER(o.nombre) LIKE LOWER(CONCAT('%', :nombre, '%'))) AND " +
           "(:categoriaId IS NULL OR o.categoria.id = :categoriaId) AND " +
           "(:modalidadId IS NULL OR o.modalidad.id = :modalidadId) AND " +
           "o.activo = true")
    Page<OfertaAcademica> buscarConFiltros(@Param("nombre") String nombre,
                                            @Param("categoriaId") Long categoriaId,
                                            @Param("modalidadId") Long modalidadId,
                                            Pageable pageable);
}
