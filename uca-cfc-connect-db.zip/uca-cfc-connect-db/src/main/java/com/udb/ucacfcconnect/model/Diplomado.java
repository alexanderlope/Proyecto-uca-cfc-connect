package com.udb.ucacfcconnect.model;

import jakarta.persistence.Column;
import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@DiscriminatorValue("DIPLOMADO")
@Getter
@Setter
@NoArgsConstructor
public class Diplomado extends OfertaAcademica {

    @Column(name = "duracion")
    private Integer duracion; // en horas o semanas, según se defina en negocio
}
