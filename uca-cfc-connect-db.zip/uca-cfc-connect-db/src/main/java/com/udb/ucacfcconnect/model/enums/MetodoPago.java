package com.udb.ucacfcconnect.model.enums;

public enum MetodoPago {
    EFECTIVO,
    TARJETA,
    TRANSFERENCIA,
    DEPOSITO
}
