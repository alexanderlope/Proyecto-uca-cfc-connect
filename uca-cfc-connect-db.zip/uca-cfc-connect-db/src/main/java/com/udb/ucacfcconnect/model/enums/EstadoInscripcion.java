package com.udb.ucacfcconnect.model.enums;

public enum EstadoInscripcion {
    PENDIENTE,
    CONFIRMADA,
    CANCELADA,
    FINALIZADA
}
