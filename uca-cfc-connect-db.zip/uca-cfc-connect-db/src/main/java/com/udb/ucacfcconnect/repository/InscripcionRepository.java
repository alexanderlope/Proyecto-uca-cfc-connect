package com.udb.ucacfcconnect.repository;

import com.udb.ucacfcconnect.model.Inscripcion;
import com.udb.ucacfcconnect.model.enums.EstadoInscripcion;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface InscripcionRepository extends JpaRepository<Inscripcion, Long> {

    Page<Inscripcion> findByClienteId(Long clienteId, Pageable pageable);

    Page<Inscripcion> findByEstado(EstadoInscripcion estado, Pageable pageable);

    List<Inscripcion> findByOfertaAcademicaIdAndEstadoIn(Long ofertaAcademicaId, List<EstadoInscripcion> estados);

    long countByOfertaAcademicaIdAndEstadoIn(Long ofertaAcademicaId, List<EstadoInscripcion> estados);
}
