package com.udb.ucacfcconnect.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "rol")
@Getter
@Setter
@NoArgsConstructor
public class Rol {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 50)
    private String nombre; // ADMIN, RECEPCIONISTA, CLIENTE, CONTABILIDAD

    @Column(length = 255)
    private String descripcion;

    @OneToMany(mappedBy = "rol")
    private Set<Usuario> usuarios = new HashSet<>();
}
