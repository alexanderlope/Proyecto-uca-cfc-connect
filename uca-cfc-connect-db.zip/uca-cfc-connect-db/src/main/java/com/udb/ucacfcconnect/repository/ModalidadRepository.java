package com.udb.ucacfcconnect.repository;

import com.udb.ucacfcconnect.model.Modalidad;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ModalidadRepository extends JpaRepository<Modalidad, Long> {
}
