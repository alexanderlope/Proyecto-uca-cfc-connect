package com.udb.ucacfcconnect.repository;

import com.udb.ucacfcconnect.model.Pago;
import com.udb.ucacfcconnect.model.enums.EstadoPago;
import com.udb.ucacfcconnect.model.enums.TipoReferenciaPago;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PagoRepository extends JpaRepository<Pago, Long> {

    Page<Pago> findByClienteId(Long clienteId, Pageable pageable);

    Page<Pago> findByEstado(EstadoPago estado, Pageable pageable);

    Page<Pago> findByTipoReferenciaAndReferenciaId(TipoReferenciaPago tipoReferencia, Long referenciaId, Pageable pageable);
}
