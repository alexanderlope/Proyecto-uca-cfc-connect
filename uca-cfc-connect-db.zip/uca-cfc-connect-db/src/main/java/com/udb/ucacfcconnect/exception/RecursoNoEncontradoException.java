package com.udb.ucacfcconnect.exception;

/** Se lanza cuando no se encuentra un registro por id (cliente, curso, espacio, etc.). */
public class RecursoNoEncontradoException extends RuntimeException {
    public RecursoNoEncontradoException(String mensaje) {
        super(mensaje);
    }
}
