package com.udb.ucacfcconnect.repository;

import com.udb.ucacfcconnect.model.Cotizacion;
import com.udb.ucacfcconnect.model.enums.EstadoCotizacion;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CotizacionRepository extends JpaRepository<Cotizacion, Long> {

    Page<Cotizacion> findByClienteId(Long clienteId, Pageable pageable);

    Page<Cotizacion> findByEstado(EstadoCotizacion estado, Pageable pageable);
}
