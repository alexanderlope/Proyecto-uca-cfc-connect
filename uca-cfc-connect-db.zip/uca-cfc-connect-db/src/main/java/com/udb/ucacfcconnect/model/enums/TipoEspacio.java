package com.udb.ucacfcconnect.model.enums;

public enum TipoEspacio {
    AUDITORIO,
    SALA_REUNIONES,
    LABORATORIO,
    AULA,
    SALA_MULTIMEDIA
}
