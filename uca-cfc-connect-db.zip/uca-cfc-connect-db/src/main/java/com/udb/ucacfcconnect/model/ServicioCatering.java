package com.udb.ucacfcconnect.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Entity
@Table(name = "servicio_catering")
@Getter
@Setter
@NoArgsConstructor
public class ServicioCatering {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 100)
    private String nombre; // Coffee Break, Desayuno, Almuerzo, Cena, Refrigerio

    @Column(length = 255)
    private String descripcion;

    @Column(name = "precio_por_persona", nullable = false, precision = 10, scale = 2)
    private BigDecimal precioPorPersona;

    @Column(nullable = false)
    private Boolean activo = true;

    public BigDecimal calcularCosto(int numAsistentes) {
        return precioPorPersona.multiply(BigDecimal.valueOf(numAsistentes));
    }
}
