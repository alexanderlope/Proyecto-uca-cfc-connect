package com.udb.ucacfcconnect.model.enums;

public enum TipoCotizacion {
    CURSO,
    DIPLOMADO,
    ESPACIO,
    CATERING,
    COMBINADO
}
