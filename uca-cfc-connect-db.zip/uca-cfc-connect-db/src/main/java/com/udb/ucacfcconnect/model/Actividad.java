package com.udb.ucacfcconnect.model;

import com.udb.ucacfcconnect.model.enums.TipoActividad;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalTime;

/**
 * Representa una entrada en el calendario institucional.
 * "referenciaId" apunta al id de la OfertaAcademica, SolicitudAlquiler
 * o SolicitudCatering según el valor de "tipo" (referencia polimórfica
 * simple, sin FK física, tal como se definió en el modelo relacional).
 */
@Entity
@Table(name = "actividad")
@Getter
@Setter
@NoArgsConstructor
public class Actividad {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private TipoActividad tipo;

    @Column(name = "referencia_id", nullable = false)
    private Long referenciaId;

    @Column(nullable = false)
    private LocalDate fecha;

    @Column(name = "hora_inicio", nullable = false)
    private LocalTime horaInicio;

    @Column(name = "hora_fin", nullable = false)
    private LocalTime horaFin;

    @Column(length = 150)
    private String lugar;
}
