package com.udb.ucacfcconnect.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "cliente")
@Getter
@Setter
@NoArgsConstructor
public class Cliente {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "dui_nit", nullable = false, unique = true, length = 20)
    private String duiNit;

    @Column(nullable = false, length = 100)
    private String nombre;

    @Column(length = 100)
    private String empresa;

    @Column(length = 100)
    private String correo;

    @Column(length = 30)
    private String telefono;

    @Column(length = 255)
    private String direccion;

    @Column(nullable = false)
    private Boolean activo = true;
}
