package com.udb.ucacfcconnect.model.enums;

public enum EstadoSolicitud {
    PENDIENTE,
    CONFIRMADA,
    CANCELADA,
    RECHAZADA
}
