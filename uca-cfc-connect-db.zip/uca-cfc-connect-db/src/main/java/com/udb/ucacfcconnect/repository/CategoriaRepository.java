package com.udb.ucacfcconnect.repository;

import com.udb.ucacfcconnect.model.Categoria;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoriaRepository extends JpaRepository<Categoria, Long> {
}
