package com.udb.ucacfcconnect.repository;

import com.udb.ucacfcconnect.model.Docente;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DocenteRepository extends JpaRepository<Docente, Long> {
}
