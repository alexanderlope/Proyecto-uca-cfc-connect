package com.udb.ucacfcconnect.repository;

import com.udb.ucacfcconnect.model.Actividad;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface ActividadRepository extends JpaRepository<Actividad, Long> {

    Page<Actividad> findByFechaBetween(LocalDate fechaInicio, LocalDate fechaFin, Pageable pageable);

    List<Actividad> findByLugarAndFecha(String lugar, LocalDate fecha);
}
