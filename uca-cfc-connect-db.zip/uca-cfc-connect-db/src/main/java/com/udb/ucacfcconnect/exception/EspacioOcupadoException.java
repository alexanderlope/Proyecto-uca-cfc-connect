package com.udb.ucacfcconnect.exception;

/**
 * Se lanza cuando se intenta reservar un espacio en una fecha/horario
 * que ya tiene una solicitud de alquiler activa (ver Fase 1, flujo 8.3
 * y el caso de prueba "fallo por solapamiento").
 */
public class EspacioOcupadoException extends NegocioException {
    public EspacioOcupadoException(String mensaje) {
        super(mensaje);
    }
}
