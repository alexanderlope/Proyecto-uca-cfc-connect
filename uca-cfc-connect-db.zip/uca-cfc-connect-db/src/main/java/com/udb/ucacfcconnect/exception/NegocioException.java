package com.udb.ucacfcconnect.exception;

/** Excepción base para todas las reglas de negocio del dominio UCA-CFC Connect. */
public class NegocioException extends RuntimeException {
    public NegocioException(String mensaje) {
        super(mensaje);
    }
}
