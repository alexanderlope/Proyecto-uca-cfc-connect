package com.udb.ucacfcconnect.model.enums;

public enum EstadoCotizacion {
    PENDIENTE,
    EN_PROCESO,
    APROBADA,
    RECHAZADA
}
