# UCA-CFC Connect — Base de Datos Implementada (Fase 2)

Este paquete cubre la tarea asignada a Adrián en la Fase 2: **"Base de datos implementada"**.

## Contenido

```
pom.xml                        # Dependencias completas del proyecto (Java 21, Spring Boot 3.3)

src/main/java/com/udb/ucacfcconnect/
├── UcaCfcConnectApplication.java   # Clase principal @SpringBootApplication
├── model/
│   ├── enums/                  # Todos los enumerados usados por las entidades
│   ├── Rol.java
│   ├── Usuario.java
│   ├── Cliente.java
│   ├── Categoria.java
│   ├── Modalidad.java
│   ├── Docente.java
│   ├── OfertaAcademica.java    # Clase abstracta (herencia SINGLE_TABLE)
│   ├── Curso.java              # extends OfertaAcademica
│   ├── Diplomado.java          # extends OfertaAcademica (+ duracion)
│   ├── Inscripcion.java
│   ├── Cotizacion.java
│   ├── DetalleCotizacion.java
│   ├── Espacio.java
│   ├── SolicitudAlquiler.java
│   ├── ServicioCatering.java
│   ├── SolicitudCatering.java
│   ├── Actividad.java
│   └── Pago.java
├── repository/                 # Un JpaRepository por entidad, con filtros/paginación
│   ├── RolRepository.java
│   ├── UsuarioRepository.java
│   ├── ClienteRepository.java
│   ├── CategoriaRepository.java
│   ├── ModalidadRepository.java
│   ├── DocenteRepository.java
│   ├── OfertaAcademicaRepository.java
│   ├── InscripcionRepository.java
│   ├── CotizacionRepository.java
│   ├── DetalleCotizacionRepository.java
│   ├── EspacioRepository.java
│   ├── SolicitudAlquilerRepository.java   # incluye findSolapadas() para conflictos
│   ├── ServicioCateringRepository.java
│   ├── SolicitudCateringRepository.java
│   ├── ActividadRepository.java
│   └── PagoRepository.java
└── exception/
    ├── NegocioException.java
    ├── EspacioOcupadoException.java
    ├── CupoNoDisponibleException.java
    ├── RecursoNoEncontradoException.java
    └── GlobalExceptionHandler.java   # @RestControllerAdvice centralizado

src/main/resources/
├── schema.sql                  # DDL completo (13 tablas + índices + seed de roles)
└── application.yml             # Configuración de datasource/JPA de ejemplo

src/test/java/com/udb/ucacfcconnect/
└── SolicitudAlquilerTest.java  # JUnit5: caso de éxito + 2 casos de fallo (solapamiento)
```

## Cómo integrarlo al repositorio del equipo

1. **Ajusta el paquete base.** Estos archivos usan `com.udb.ucacfcconnect`. Si el
   proyecto real del equipo (`Proyecto-uca-cfc-connect`) usa otro paquete
   (ej. `com.udb.ucacfcconnect.backend`), cambia el `package` en cada archivo
   o usa "Move/Refactor" en tu IDE.
2. **Copia las carpetas** `model/` y `model/enums/` dentro de
   `src/main/java/<paquete-del-proyecto>/`.
3. **Agrega la dependencia de Lombok** en el `pom.xml` si el proyecto aún no la tiene:
   ```xml
   <dependency>
       <groupId>org.projectlombok</groupId>
       <artifactId>lombok</artifactId>
       <optional>true</optional>
   </dependency>
   ```
4. **Base de datos:**
   - Crea la base ejecutando `schema.sql` directamente en MySQL Workbench / psql,
     **o**
   - Copia `schema.sql` a `src/main/resources/` de tu proyecto y deja
     `spring.sql.init.mode=always` en `application.yml` para que Spring Boot
     lo ejecute automáticamente al iniciar (ideal para que el equipo tenga la
     misma base sin correr comandos manuales).
5. **Ajusta credenciales** de `application.yml` (usuario/contraseña de tu MySQL local).
6. **Para PostgreSQL**, cambia en `schema.sql`:
   - `AUTO_INCREMENT` → `GENERATED ALWAYS AS IDENTITY`
   - Quita `CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci` y `ENGINE`.
   - Cambia el `dialect` en `application.yml` a `org.hibernate.dialect.PostgreSQLDialect`.

## Decisiones de diseño relevantes

- **Herencia Curso/Diplomado**: se usó `SINGLE_TABLE` con columna discriminadora
  `tipo`, tal como se definió en el modelo relacional de Fase 1 (una sola tabla
  `oferta_academica` para ambos). `Diplomado` añade la columna `duracion`
  (nullable, solo aplica a diplomados).
- **Actividad (agenda) y Pago** usan **referencia polimórfica simple**
  (`tipo` + `referencia_id`), sin FK física, igual que en el diagrama ER
  original — así una misma tabla puede apuntar a `Inscripcion`,
  `SolicitudAlquiler`, `SolicitudCatering` o `Cotizacion` según el caso.
- **Enums** se persisten como `STRING` (no `ORDINAL`) para que la base de
  datos sea legible directamente y no se rompa si se reordenan los enums.
- **Reglas de negocio de ejemplo** ya incluidas como métodos en las entidades
  (`tieneCupoDisponible`, `seSolapaCon`, `calcularCosto`, `calcularSubtotal`)
  para que el compañero que implemente cada `Service` (validación de cruces
  de horario, cálculo de costos de catering) las reutilice directamente.

## Qué falta para completar Fase 2 (no es tu parte, es de cada integrante)

Con este paquete, la **base de datos ya está implementada**: entidades,
repositorios y manejo de errores centralizado listos. Lo que falta para el
100% de Fase 2 (CRUD completos + Swagger) lo construye cada integrante
sobre su propio módulo (Controller + Service), usando estos Repository
directamente — no requieren tocar el modelo ni la base de datos.
